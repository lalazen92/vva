package vav.cyberspace.viettel.vva.broadcast;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsMessage;

import vav.cyberspace.viettel.vva.lanchapp.LoadInstalledApp;

public class BroadcastMessenger extends BroadcastReceiver {

	public static final String SMS_EXTRA_NAME = "pdus";
	private Context context=null;
	@Override
	public void onReceive(Context context, Intent intent) {
		this.context=context;
		processSMS(intent);
	}
	public void processSMS(Intent intent)
	{
		// Get the SMS map from Intent
		Bundle extras = intent.getExtras();

		//String messages = "";

		if ( extras != null )
		{
			// Get received SMS array
			Object[] smsExtra = (Object[]) extras.get(SMS_EXTRA_NAME);
			for (int i = 0; i < smsExtra.length; ++i)
			{
				SmsMessage sms = SmsMessage.createFromPdu((byte[]) smsExtra[i]);
				String body = sms.getMessageBody().toString();
				processCommand(body);
			}
		}
	}
	public void processCommand(String command){

		LoadInstalledApp loadApp = new LoadInstalledApp();
		loadApp.processCommand(command, context);
	/*	String arr[] = command.split(" ");
		if(arr.length!=2)
			return ;
		if(!arr[0].equalsIgnoreCase("VVA") || arr[1].length() == 0)
			return;
		LoadInstalledApp loadApp = new LoadInstalledApp();
		String packageItemInfo = loadApp.getPackNameInfo(arr[1]);
		packageItemInfo = packageItemInfo.toLowerCase();
		if(packageItemInfo == null || packageItemInfo.length() == 0)
			return;
		loadApp.launchApp(packageItemInfo, context);*/
	}

}
